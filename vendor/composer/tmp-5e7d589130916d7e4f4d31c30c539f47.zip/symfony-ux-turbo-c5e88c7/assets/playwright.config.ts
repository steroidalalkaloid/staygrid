import baseConfig from '../../../playwright.config.base';

export default baseConfig;
