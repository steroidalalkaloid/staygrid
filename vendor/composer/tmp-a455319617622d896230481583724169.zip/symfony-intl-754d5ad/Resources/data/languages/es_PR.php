<?php

return [
    'Names' => [
        'ace' => 'acehnés',
        'arp' => 'arapaho',
        'bho' => 'bhojpuri',
        'grc' => 'griego antiguo',
        'nso' => 'sotho septentrional',
        'ss' => 'siswati',
        'wo' => 'wolof',
    ],
    'LocalizedNames' => [],
];
