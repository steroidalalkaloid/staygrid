<?php

return [
    'Names' => [
        'MYR' => [
            'RM',
            'Malaysian Ringgit',
        ],
    ],
];
