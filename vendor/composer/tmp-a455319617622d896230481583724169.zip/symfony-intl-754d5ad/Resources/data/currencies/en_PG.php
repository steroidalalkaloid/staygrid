<?php

return [
    'Names' => [
        'PGK' => [
            'K',
            'Papua New Guinean Kina',
        ],
    ],
];
