<?php

return [
    'Names' => [
        'MUR' => [
            'Rs',
            'roupie mauricienne',
        ],
    ],
];
