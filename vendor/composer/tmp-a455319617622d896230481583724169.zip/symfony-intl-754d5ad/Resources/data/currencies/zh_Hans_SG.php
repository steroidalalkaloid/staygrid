<?php

return [
    'Names' => [
        'CNY' => [
            'CN¥',
            '人民币',
        ],
        'SGD' => [
            '$',
            '新加坡元',
        ],
    ],
];
