<?php

return [
    'Names' => [
        'NOK' => [
            'kr',
            'Norwegian Krone',
        ],
    ],
];
