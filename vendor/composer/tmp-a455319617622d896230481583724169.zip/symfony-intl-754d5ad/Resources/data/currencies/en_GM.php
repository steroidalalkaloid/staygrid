<?php

return [
    'Names' => [
        'GMD' => [
            'D',
            'Gambian Dalasi',
        ],
    ],
];
