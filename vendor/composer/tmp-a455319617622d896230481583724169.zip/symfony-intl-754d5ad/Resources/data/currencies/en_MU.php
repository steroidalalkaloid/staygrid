<?php

return [
    'Names' => [
        'MUR' => [
            'Rs',
            'Mauritian Rupee',
        ],
    ],
];
