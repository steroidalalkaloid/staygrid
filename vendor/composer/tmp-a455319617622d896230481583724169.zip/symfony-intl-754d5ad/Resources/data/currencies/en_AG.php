<?php

return [
    'Names' => [
        'XCD' => [
            '$',
            'East Caribbean Dollar',
        ],
    ],
];
